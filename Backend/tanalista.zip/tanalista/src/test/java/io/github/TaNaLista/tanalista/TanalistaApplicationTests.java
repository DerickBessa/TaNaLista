package io.github.TaNaLista.tanalista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TanalistaApplicationTests {

	@Test
	void contextLoads() {
	}

}
